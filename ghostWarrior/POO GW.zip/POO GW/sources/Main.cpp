/*
 * MainTest.cpp
 *
 * Polytech Marseille
 * Case 925 -163, avenue de Luminy
 * 13288 Marseille CEDEX 9
 *
 * Ce fichier est l'oeuvre d'eleves de Polytech Marseille. Il ne peut être
 * reproduit, utilise ou modifie sans l'avis express de ses auteurs.
*/

/**
 * @author DENIS Justine <justine.denis@etu.univ-amu.fr>
 * @author GALAN-DELEA Sergio <sergio.galan-delea@etu.univ-amu.fr>
 *
 * @version 1 / 24-11-2016
 * @Resume: Fichier main permettant de tester les classes
 * @toto NA
 * @bug NA
*/


#include "Coordonne.h"
#include "Personnage.h"
#include "Ennemi.h"
#include "Joueur.h"
#include "Map.h"
#include "Evenement.hpp"

#include <iostream>
using namespace std;




int main()
{
    Evenement evenement;
    Map carte;
    Joueur ghost1(1,320,420,100,200,carte,"PLAYER1");
    //Ennemi en(1,2,2,100,200,carte);


    //-----------------------------CLASS GRAPHIQUE A FAIRE-----------------------------------------------

    sf::Texture Background;
    if (!Background.loadFromFile("fond_ville_nuit.png"))
    {
    // error...
        cout<<"erreur chargement texture"<<endl;
    }

    sf::Texture Ghost;
    if (!Ghost.loadFromFile("fantome_essai_pixel_ia.png"))
    {
    // error...
        cout<<"erreur chargement texture"<<endl;
    }
    Ghost.setSmooth(true);
    sf::Sprite ghost;
    ghost.setTexture(Ghost);
    ghost.setScale(0.15f,0.15f);
    //ghost.setPosition(0,0);
    ghost.setOrigin(495,652);

    sf::Sprite background;
    background.setTexture(Background);
    background.scale(2.3f,3.2f);

    //plateforme
    sf::Texture plateforme;
    if (!plateforme.loadFromFile("brique.png"))
    {
        cout<<"erreur chargement texture"<<endl;
    }
    plateforme.setSmooth(true);
    plateforme.setRepeated(true);           //repete la plateforme
    sf::Sprite platef;                      //creation sprite
    platef.setTexture(plateforme);
    platef.setTextureRect(sf::IntRect(1, 0, carte.getLargeurCase(), carte.getLongeurCase()));


    //----------------------------------------------------------------------------


    //boucle principale
    while(evenement.window.isOpen()){

        evenement.KeyBoardEventJ();           //recupe clavier
        ghost1.UpdatePerso(evenement.left,evenement.right);                    // mise a jour du perso(application vitesse/gravite/acceleration)
        ghost1.Jump(evenement.jump);                           // fonction pour sauter
        ghost1.ColisionEnv();                       // collision mur lateral et sol -> a ameliorer pour suivre map
        ghost1.colision(evenement.jump);

        ghost.setPosition(ghost1.pos);              // mise a jour de la position du perso

        evenement.window.clear();                   //effaçage de l'ecran
        evenement.window.draw(background);          // dessin fond
        for(int i=0; i<20; i++)
        {
           for(int j=0; j<20; j++)
            {
                if(carte.infos_case(i,j) == 1)
                {
                    platef.setPosition(sf::Vector2f(i*carte.getLargeurCase(),j*carte.getLargeurCase())); // position absolue
                    evenement.window.draw(platef);              //dessin plateforme
                }
           }
        }

        evenement.window.draw(ghost);               // dessin joueur
        evenement.window.display();                 // afichage ecran
    }

	return 0;
}
